/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_8_listasimple;


public class Nodo {

    private int ente;
    private Nodo sig;
    

    public Nodo() {
        this.sig = null;
    }

    public Nodo(int ente) {
        this.ente = ente;
        this.sig = null;
    }

    public int getEnte() {
        return ente;
    }

    public void setEnte(int enterin) {
        this.ente = ente;
    }

    public Nodo getSig() {
        return sig;
    }

    public void setSig(Nodo sig) {
        this.sig = sig;
    }

}
