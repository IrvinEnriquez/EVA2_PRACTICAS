/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_1_recursividad;

import java.util.Scanner;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_1_Recursividad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner d= new Scanner(System.in);
        System.out.println("Ingrese el numero");
        int numero= d.nextInt();
        for (int i = numero; i >=1 ; i--) {
            System.out.println(i+"-");
        }
        System.out.println("");
        forFalso(numero);
        System.out.println("");
        forFalso2(numero, 1);
    }
    public static void forFalso(int iVal){
        System.out.println(iVal+"-");
        if(iVal>1){
        forFalso(iVal-1);
        }
       
            
        }
     public static void forFalso2(int num, int inc){
            System.out.println(inc+"-");
            if(inc<num){
            forFalso2(num, inc+1);
            }
    
    }
    
}
