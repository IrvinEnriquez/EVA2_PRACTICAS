/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_10_pila;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Irvin Papu
 */
class Pila {
    private Nodo inicio;
    private Nodo fin;

    public Pila() {
        this.inicio = null;
        this.fin = null;
    }

    public boolean isEmpty() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public void add(Nodo nuevo) {
        if (isEmpty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }
    }

    public void print() {
        Nodo temp = inicio;
        while (temp != null) {
            System.out.print(temp.getValor() + " - ");
            temp = temp.getSiguiente();
        }
        System.out.println("");
    }

    public int size() {
        int Cont = 0;
        Nodo temp = inicio;
        while (temp != null) {
            Cont++;
            temp = temp.getSiguiente();
        }
        return Cont;
    }

    public void addBegin(Nodo nuevo) {
        if (isEmpty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        }
    }

    public void insertAt(int pos, Nodo nuevo) {
        int Tama = size();
        if (pos < 0 || pos >= Tama) {
            try {
                throw new Exception("Posición inválida");
            } catch (Exception ex) {
                Logger.getLogger(Pila.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            if (pos == 0) {
                addBegin(nuevo);
            } else {
                int Cont = 0;

                Nodo temp = inicio;
                while (Cont < (pos - 1)) {
                    temp = temp.getSiguiente();
                    Cont++;
                }
                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);
            }
        }
    }
    public void clear(){
        inicio = null;
        fin = null;
    }
    public void deleteAt(int pos){
        try {
            if(isEmpty()== true){
                    throw new Exception("La lista está vacía"); 
            }
            int Tama = size();
            if((pos<0)||pos>=Tama)
                throw new Exception("La posición es inválida");
            if (Tama==1) {
                clear();
            }else{
                if (pos==0) {
                    inicio= inicio.getSiguiente();
                }else{
                    int Cont = 0;
                    
                    Nodo temp = inicio;
                    while (Cont < (pos - 1)) {
                        temp = temp.getSiguiente();
                        Cont++;
                    }
                    temp.setSiguiente(temp.getSiguiente().getSiguiente());
                    if(pos==(Tama-1)){
                        fin = temp;
                    }
                }
            }
            if(pos==0){
                inicio = inicio.getSiguiente();
            }
            if(size()==1){
                inicio=null;
                fin=null;
            }
        } catch (Exception ex) {
            Logger.getLogger(Pila.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public int findAt(int pos){
        int Cont=0;
        Nodo temp= inicio;
        while (Cont < (pos - 1)) {
                    temp = temp.getSiguiente();
                    Cont++;
                }
        return temp.getValor();
    }
    public void push(Nodo nuevo){
        addBegin(nuevo);
    }
    public int peek(){
        return findAt(0);
    }
    public int pop()throws Exception{
        int iResu=findAt(0);
        deleteAt(0);
        return iResu;
    }
}

    


    

