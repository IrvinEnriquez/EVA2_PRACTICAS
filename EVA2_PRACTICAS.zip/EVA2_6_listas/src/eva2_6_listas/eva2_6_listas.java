package eva2_6_listas;

public class eva2_6_listas {

    /**
 *
 * @author Irvin Papu
 */
    public static void main(String[] args) {
        // TODO code application logic here
Nodo nObj1= new Nodo();
        nObj1.valor= 100;
        nObj1.sig= new Nodo();
        nObj1.sig.valor=200;
        nObj1.sig.sig= new Nodo();
        nObj1.sig.sig.valor=300;
        System.out.println(nObj1.valor);
        System.out.println(nObj1.sig.valor);
        System.out.println(nObj1.sig.sig.valor);
    }        
    
    
    
}

class Nodo{
//Dato a almacenar
    int valor;
   Nodo sig;
   
}