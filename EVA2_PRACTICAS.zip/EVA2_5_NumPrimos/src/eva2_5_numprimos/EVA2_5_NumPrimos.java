/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_5_numprimos;

import java.util.Scanner;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_5_NumPrimos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner d= new Scanner(System.in);
         System.out.println("Dame un numero");
         int r= d.nextInt();
         if(esPrimoIneficiente(r))
             System.out.println("Es norteño, digo primo");
         else
             System.out.println("No es norteño");
    }
    public static boolean esPrimoIneficiente(int val){
        boolean Resu= true;
        for (int i = 2; i < val; i++) {
        if((val%i)==0){
        Resu= false;
        break;
    }
    }
        return Resu;
}
    

    
    
}
