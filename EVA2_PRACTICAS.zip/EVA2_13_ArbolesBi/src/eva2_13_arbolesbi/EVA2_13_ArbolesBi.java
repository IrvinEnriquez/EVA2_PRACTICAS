/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_13_arbolesbi;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_13_ArbolesBi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    
        Arbol d= new Arbol();
        d.agregarNodo(new Nodo(5));
        d.agregarNodo(new Nodo(40));
        d.agregarNodo(new Nodo(19));
        d.agregarNodo(new Nodo(32));
        d.agregarNodo(new Nodo(4));
        d.agregarNodo(new Nodo(6));
        d.agregarNodo(new Nodo(9));
        d.agregarNodo(new Nodo(19));
        d.imprimirPostOrder();
        System.out.println("");
        d.imprimirinOrder();
        System.out.println("");
        d.imprimirpreOrder();
    }
    
}

   