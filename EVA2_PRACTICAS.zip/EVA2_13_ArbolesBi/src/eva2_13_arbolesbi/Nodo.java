/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_13_arbolesbi;

/**
 *
 * @author Irvin Papu
 */
public class Nodo {
        private int valor;
        private Nodo izquierda;
        private Nodo derecha;

    public Nodo() {
        this.izquierda= null;
    }

    public Nodo(int valor) {
        this.valor = valor;
        this.izquierda= null;
        this.derecha= null;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }

    public Nodo getDerecha() {
        return derecha;
    }

    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
    
}

  
 

    

