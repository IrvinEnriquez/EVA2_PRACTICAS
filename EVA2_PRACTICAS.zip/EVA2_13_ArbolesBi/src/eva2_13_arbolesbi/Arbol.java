package eva2_13_arbolesbi;


    public class Arbol {
        private Nodo root;
    
        public Arbol(){
            root= null;
    }
    public void agregarNodo(Nodo nuevo){
        AgregarNodoRec(root, nuevo);
    
    }
    private void AgregarNodoRec(Nodo actual, Nodo nuevo){
        if(root==null){
        root= nuevo;
    }
    else{
        if(nuevo.getValor()>actual.getValor()){
            if(actual.getDerecha()==null){
                actual.setDerecha(nuevo);
    }else{
        AgregarNodoRec(actual.getDerecha(), nuevo);
        
    }
        
    } else if(nuevo.getValor()<actual.getValor()){
        if(actual.getIzquierda()==null){
            actual.setIzquierda(nuevo);
    }else{
        AgregarNodoRec(actual.getIzquierda(), nuevo);
        
    }
    
    }else{
    
        System.out.println("Ya existe bro");}
    
    }
    }
    public void imprimirPostOrder(){
    postOrder(root);
    
    }
    private void postOrder(Nodo Actual){
       if(Actual!=null ){
        postOrder(Actual.getIzquierda());
        postOrder(Actual.getDerecha());
        System.out.print(Actual.getValor()+"-");
    }
}
    public void imprimirinOrder(){
    inOrder(root);
    
    }
    private void inOrder(Nodo Actual){
       if(Actual!=null ){
        inOrder(Actual.getIzquierda());
        
        System.out.print(Actual.getValor()+"-");
        inOrder(Actual.getDerecha());
    }
}
 public void imprimirpreOrder(){
    preOrder(root);
    
    }
    private void preOrder(Nodo Actual){
       if(Actual!=null ){
        System.out.print(Actual.getValor()+"-");
           preOrder(Actual.getIzquierda());
        
        
        preOrder(Actual.getDerecha());
    }
}   
}