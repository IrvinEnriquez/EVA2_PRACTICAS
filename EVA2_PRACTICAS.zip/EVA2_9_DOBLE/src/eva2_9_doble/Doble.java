/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_9_doble;

/**
 *
 * @author Irvin Papu
 */
public class Doble {
        private Nodo inicio;
        private Nodo fin;
        public Doble(){
        this.inicio = null;
        this.fin = null;
    }
        
        public boolean isEmpty(){
            
            if(inicio== null){
                
                return true;
    }
        else{
            return false;
        }
        
    }
        
        public void print(){
            Nodo temp= inicio;
            while (temp!=null){
                System.out.print(temp.getValor()+"-");
                temp= temp.getSiguiente();
    }
    System.out.println("");
    

    }
    public int size(int pos){
        int iCont=0;
        Nodo temp= inicio;
        while(iCont<(pos-1)){
            temp = temp.getSiguiente();
            iCont++;
        }

return temp.getValor();
    }
    public void add(Nodo nuevo){
//Vacia
        if(isEmpty()){
            inicio = nuevo;
            fin= nuevo;
    }
        else{
        fin.setSiguiente(nuevo);
        nuevo.setPrevio(fin);
        fin= nuevo;
        }
    }

        public void printBack(){
            Nodo temp= fin;
            while (temp!=null){
            System.out.print(temp.getValor()+"-");
            temp= temp.getPrevio();
}
    System.out.println("");
    

}
}


    

