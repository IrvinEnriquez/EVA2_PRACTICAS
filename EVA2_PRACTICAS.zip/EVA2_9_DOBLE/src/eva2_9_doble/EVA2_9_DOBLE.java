/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_9_doble;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_9_DOBLE {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
       Doble miLista = new Doble();
       miLista.add(new Nodo(100));
        miLista.add(new Nodo(200));
         miLista.add(new Nodo(300));
          miLista.add(new Nodo(400));
          miLista.print();
    }
    
}
