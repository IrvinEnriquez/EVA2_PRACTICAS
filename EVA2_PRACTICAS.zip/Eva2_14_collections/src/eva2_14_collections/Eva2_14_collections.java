/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_14_collections;

import java.util.LinkedList;

/**
 *
 * @author Irvin Papu
 */
public class Eva2_14_collections {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<String> lListaEnlazada= new LinkedList<String>();
        lListaEnlazada.add("Hola");
        lListaEnlazada.add(" ");
        lListaEnlazada.add("chiquillo");
        lListaEnlazada.add("");
        lListaEnlazada.add("¿que tal?");
        lListaEnlazada.add("!!! ");
        lListaEnlazada.addFirst("-----");
        System.out.println(lListaEnlazada);
        
        for (String string : lListaEnlazada) {
            System.out.println(string+" - ");
        }
        System.out.println("");
        System.out.println("Cantidad de elementos"+ lListaEnlazada.size());
        lListaEnlazada.remove(1);
        
    }
    
}
    
    

