/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_15_arraylist;

import java.util.ArrayList;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_15_ArrayList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       ArrayList<Integer> Arrays= new ArrayList<Integer>();
       Arrays.add(12);
       Arrays.add(20);
       Arrays.add(540);
       Arrays.add(70);
       Arrays.add(5);
       Arrays.add(8);
    }
    
}
