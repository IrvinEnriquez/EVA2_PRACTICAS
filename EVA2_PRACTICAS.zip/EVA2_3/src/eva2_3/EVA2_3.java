/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_3;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("El maximo comun divisor de:");
        System.out.println(MCD(1000, 500));
    }
    public static int MCD(int dividendo, int divisor){
        System.out.println(dividendo +"/"+ divisor);
        if(divisor==0){
            return dividendo;
        }else{
            int Resu=dividendo%divisor;
            
            return MCD(divisor, Resu);
        }
    
    }
    
}
