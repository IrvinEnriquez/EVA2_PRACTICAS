/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_2factorial;

/**
 *
 * @author Irvin Papu
 */
public class EVA2_2FACTORIAL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Factorial de 7 "+calculaFactorial(7));
    }
    public static int calculaFactorial(int iVal){
        System.out.println("Inicio "+ iVal);
            if (iVal==0)
            return 1;
        return iVal*calculaFactorial(iVal-1);


}
    }
    

